<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['login'] = 'employee/login';
$route['forgot_password'] = 'employee/forgot_password';
$route['logout'] = 'employee/logout';
$route['dashboard'] = 'employee/dashboard';

$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
